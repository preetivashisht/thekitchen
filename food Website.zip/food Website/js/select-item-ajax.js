// NOTE: This example will not work locally in all browsers. 
// Please try it out on the website for the book http://javascriptbook.com/code/c08/
// or run it on your own server.

$(function() {                                    // When the DOM is ready

  var times;                                      // Declare global variable
  $.ajax({
    beforeSend: function(xhr) {                   // Before requesting data
      if (xhr.overrideMimeType) {                 // If supported
        xhr.overrideMimeType("application/json"); // set MIME to prevent errors
      }
    }
  });

  // FUNCTION THAT COLLECTS DATA FROM THE JSON FILE
  function loadTimetable() {                    // Declare function
    $.getJSON('../website/data/select-item-ajax.json')              // Try to collect JSON data
    .done( function(data){                      // If successful
      times = data;                             // Store it in a variable
    }).fail( function() {                       // If a problem: show message
      $('.box2').html('Sorry! We could not load the timetable at the moment');
    });
  }

  loadTimetable();                              // Call the function


  // CLICK ON THE EVENT TO LOAD A TIMETABLE 
  $('#boxes2').on('click', '.box2 a', function(e) {  // User clicks on event

    e.preventDefault();                                // Prevent loading page
    var loc = this.id;                   // Get value of id attr

    var newContent = '';                               // Build up timetable by
    for (var i = 0; i < times[loc].length; i++) { 
	// looping through events
      newContent += '<div class="box3">';
      newContent += '<a class="black-color" href="descriptions.html#';
      newContent += times[loc][i].title.replace(/ /g, '-') + '">';
      newContent += times[loc][i].title + '</a></div>';
    }
	
	
    $('#food-items-list').html(newContent); // Display times on page

    $('.box2 a.blue-color').removeClass('blue-color');       // Update selected item
    $(this).addClass('blue-color');

    $('#details').text('');                             // Clear third column
  });

  // CLICK ON A SESSION TO LOAD THE DESCRIPTION
  $('#food-items-list').on('click', '.box3  a', function(e) { // Click on session
    e.preventDefault();                                     // Prevent loading
    var fragment = this.href;                               // Title is in href

    fragment = fragment.replace('#', ' #'); 					// Add space after#
    $('#food-items-detail').load(fragment);                           // To load info

    $('#food-items-list a.blue-color').removeClass('blue-color');        // Update selected
    $(this).addClass('blue-color');
  });


});